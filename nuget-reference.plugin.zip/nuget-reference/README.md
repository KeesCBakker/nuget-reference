#NuGet Reference for WordPress

Adds a nice looking NuGet reference to your blog posts using the [nuget] shortcode.

Examples: <br/>
[nuget]Install-Package Microsoft.CodeAnalysis -Pre[/nuget] <br/>
[nuget href="https://www.nuget.org/packages/Microsoft.CodeAnalysis"]Install-Package Microsoft.CodeAnalysis -Pre[/nuget]
